﻿namespace Pong {
    partial class PongForm {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private System.Windows.Forms.PictureBox aBall;
        private System.Windows.Forms.Timer aTimer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label aLabelPlayer2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label aLabelPlayer1;
    }
}

