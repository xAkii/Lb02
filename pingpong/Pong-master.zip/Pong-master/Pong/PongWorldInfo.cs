﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pong {
    public static class PongWorldInfo {
        public const int topOfWorld = 0, bottomOfWorld = 815, leftOfWorld = 0, rightOfWorld = 1324;
    }
}
